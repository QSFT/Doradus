1-2-3 Process
=============
- For Linux/Mac
1. Download the distribution Doradus-distribution-x.x.tar
2. Untar $tar -xvf Doradus-distribution-x.x.tar
3. Run $./doradus-dist-run.sh

To stop Doradus/Cassandra together, run $./doradus-dist-stop.sh

- For Windows
1. Download the distribution Doradus-distribution-x.x.zip
2. Unzip 
3. Run $./doradus-dist-run.bat