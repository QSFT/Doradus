package com.dell.doradus.persistence.query;

public class ObjectQueryBuilder extends QueryBuilder{
	
	
}
